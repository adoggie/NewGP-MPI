var classnc_1_1_shape =
[
    [ "Shape", "classnc_1_1_shape.html#a0f41587a1b8f1c2b65035adc49705eec", null ],
    [ "Shape", "classnc_1_1_shape.html#a6e870e9fda60c8e82996802fcb71490a", null ],
    [ "Shape", "classnc_1_1_shape.html#a4b2cd200804257d9c53084f14fb38e31", null ],
    [ "isnull", "classnc_1_1_shape.html#a3c8d187f677e9a4cdbdf1906d612b596", null ],
    [ "issquare", "classnc_1_1_shape.html#a939dd0ab6edf83b7abaf8b8c93a99152", null ],
    [ "operator!=", "classnc_1_1_shape.html#a56c44db7af73bc585c83e094da8996b5", null ],
    [ "operator==", "classnc_1_1_shape.html#a0267d8b7eb226fdc442be5c914f9c870", null ],
    [ "print", "classnc_1_1_shape.html#a494a3d8467911c47d56aa881e11a69f1", null ],
    [ "size", "classnc_1_1_shape.html#ab29f87cc8479a2d0610a918cd9b08bbc", null ],
    [ "str", "classnc_1_1_shape.html#aadb0e0d633d64e5eb5a4f9bef12b26c4", null ],
    [ "operator<<", "classnc_1_1_shape.html#a520d818f31bbdacdf8cfbe6de9e88a28", null ],
    [ "cols", "classnc_1_1_shape.html#aae1a3c997648aacaefb60d0e6d0bf10d", null ],
    [ "rows", "classnc_1_1_shape.html#a6f89f699dea6eb89eef19e00c92b223a", null ]
];