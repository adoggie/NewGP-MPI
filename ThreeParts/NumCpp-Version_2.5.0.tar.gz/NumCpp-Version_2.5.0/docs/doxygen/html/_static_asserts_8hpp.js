var _static_asserts_8hpp =
[
    [ "STATIC_ASSERT_ARITHMETIC", "_static_asserts_8hpp.html#a36abb32368b91aed0d3133a4cfd5ae92", null ],
    [ "STATIC_ASSERT_ARITHMETIC_OR_COMPLEX", "_static_asserts_8hpp.html#a1589f74d429e30786c65cda69b17ab96", null ],
    [ "STATIC_ASSERT_COMPLEX", "_static_asserts_8hpp.html#a1cd1b98c2b918cbd369afc12c11a0597", null ],
    [ "STATIC_ASSERT_FLOAT", "_static_asserts_8hpp.html#a0cd8e186da549fbdd918111d0302d973", null ],
    [ "STATIC_ASSERT_INTEGER", "_static_asserts_8hpp.html#a187660686583e9047c0cf4424259ad10", null ],
    [ "STATIC_ASSERT_VALID_DTYPE", "_static_asserts_8hpp.html#a00cfe1ea01e56fe28ffe3d6ce5cae468", null ]
];