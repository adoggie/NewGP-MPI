var _pybind_interface_8hpp =
[
    [ "pbArray", "_pybind_interface_8hpp.html#adfe4a3d878913657435705edfb3c331d", null ],
    [ "pbArrayGeneric", "_pybind_interface_8hpp.html#a92c5b0b49fb9d54b885582f85ff25d4f", null ],
    [ "ReturnPolicy", "_pybind_interface_8hpp.html#a0ca16a67f36ad5d1960cd9567208ed19", [
      [ "COPY", "_pybind_interface_8hpp.html#a0ca16a67f36ad5d1960cd9567208ed19ae8606d021da140a92c7eba8d9b8af84f", null ],
      [ "REFERENCE", "_pybind_interface_8hpp.html#a0ca16a67f36ad5d1960cd9567208ed19adcd320d017d7f3c317bc8b234287bc9f", null ],
      [ "TAKE_OWNERSHIP", "_pybind_interface_8hpp.html#a0ca16a67f36ad5d1960cd9567208ed19a9419303c1fae01a65adc8d1835aa2c6d", null ]
    ] ],
    [ "nc2pybind", "_pybind_interface_8hpp.html#adf2283c3c717906d9ddfbd73f3ab8927", null ],
    [ "nc2pybind", "_pybind_interface_8hpp.html#a10c33cf2d4fc1d454901280f1a2dc861", null ],
    [ "pybind2nc", "_pybind_interface_8hpp.html#ab473eb4036fcf02ed3c15342956cc9db", null ],
    [ "pybind2nc_copy", "_pybind_interface_8hpp.html#a1bbfbfcb2ba31e4364d101820bfc2ff8", null ],
    [ "returnPolicyStringMap", "_pybind_interface_8hpp.html#abde82685837c3645f506b0800472ffbc", null ]
];