var _filter_2_filters_2_filters2d_2laplace_8hpp =
[
    [ "laplace", "_filter_2_filters_2_filters2d_2laplace_8hpp.html#aae2d06efe29180faf7363b9322588f46", null ]
];