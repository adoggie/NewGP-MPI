var average_8hpp =
[
    [ "average", "average_8hpp.html#a9025fe780f7cb82e65c21738672f1d41", null ],
    [ "average", "average_8hpp.html#a08d310c2089324a7106ff509b862f5c7", null ],
    [ "average", "average_8hpp.html#a4d65d31c652a1ab639089ab948d0d557", null ]
];