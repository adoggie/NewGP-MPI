var classnc_1_1_timer =
[
    [ "ChronoClock", "classnc_1_1_timer.html#a968ad8ca046ae73671e211e644682c8d", null ],
    [ "TimePoint", "classnc_1_1_timer.html#a29e54a50e709622942a33e70b1b1e8f6", null ],
    [ "Timer", "classnc_1_1_timer.html#a5dabfba271b3655326e46c633eabd70e", null ],
    [ "Timer", "classnc_1_1_timer.html#a4ede5d1d2cdf6b97bec93b0954ddb610", null ],
    [ "setName", "classnc_1_1_timer.html#a88dd680a63b38ae9989a40878a8fd65b", null ],
    [ "sleep", "classnc_1_1_timer.html#a9fec514ed605a11c6e1c321041960d7e", null ],
    [ "tic", "classnc_1_1_timer.html#a4a08ec3e6ba7a7979cb9e72d0cf3f2f7", null ],
    [ "toc", "classnc_1_1_timer.html#a317fde3b5e7444328adf6484e0ec832e", null ]
];