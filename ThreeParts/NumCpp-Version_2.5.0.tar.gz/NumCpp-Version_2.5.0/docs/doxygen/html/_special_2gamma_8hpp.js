var _special_2gamma_8hpp =
[
    [ "gamma", "_special_2gamma_8hpp.html#a07a3d6d5e0610dca66ca975cdf1d34b9", null ],
    [ "gamma", "_special_2gamma_8hpp.html#aad22d353f040026576c4a28727ecaf35", null ]
];