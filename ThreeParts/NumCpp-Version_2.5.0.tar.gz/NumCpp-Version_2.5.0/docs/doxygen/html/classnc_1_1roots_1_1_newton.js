var classnc_1_1roots_1_1_newton =
[
    [ "Newton", "classnc_1_1roots_1_1_newton.html#ab5b82361c4ce325e6165e023c0255d3e", null ],
    [ "Newton", "classnc_1_1roots_1_1_newton.html#aecc72e3899f42b277536689439ea24bc", null ],
    [ "~Newton", "classnc_1_1roots_1_1_newton.html#a25702b087e2e9917af0c31fe1dbdf442", null ],
    [ "incrementNumberOfIterations", "classnc_1_1roots_1_1_newton.html#ad0262a1a694e734ebc154c77f010bcff", null ],
    [ "numIterations", "classnc_1_1roots_1_1_newton.html#ab3192d0f9de4b8b27b23013c65489e5a", null ],
    [ "resetNumberOfIterations", "classnc_1_1roots_1_1_newton.html#a85e79a4794bc3a6ac6bc3564956737a2", null ],
    [ "solve", "classnc_1_1roots_1_1_newton.html#aaed2535d1abdb0c6790aea60762ed789", null ],
    [ "epsilon_", "classnc_1_1roots_1_1_newton.html#a5eafe219bb90f82da4ece84f012a411a", null ],
    [ "maxNumIterations_", "classnc_1_1roots_1_1_newton.html#a9b1c4ea8cf91c5308020c105293b4a02", null ],
    [ "numIterations_", "classnc_1_1roots_1_1_newton.html#a84d7f2f7412d1f54861edeacc7bc0c20", null ]
];