var _dec_8hpp =
[
    [ "Dec", "classnc_1_1coordinates_1_1_dec.html", "classnc_1_1coordinates_1_1_dec" ],
    [ "Sign", "_dec_8hpp.html#a07a05f0462e5f74f05cbd04664c4ca94", [
      [ "NEGATIVE", "_dec_8hpp.html#a07a05f0462e5f74f05cbd04664c4ca94a50546bf973283065b6ccf09faf7a580a", null ],
      [ "POSITIVE", "_dec_8hpp.html#a07a05f0462e5f74f05cbd04664c4ca94aab6c31432785221bae58327ef5f6ea58", null ]
    ] ]
];