var argmin_8hpp =
[
    [ "argmin", "argmin_8hpp.html#ae26281f75850e9b94272228b56544bd5", null ]
];