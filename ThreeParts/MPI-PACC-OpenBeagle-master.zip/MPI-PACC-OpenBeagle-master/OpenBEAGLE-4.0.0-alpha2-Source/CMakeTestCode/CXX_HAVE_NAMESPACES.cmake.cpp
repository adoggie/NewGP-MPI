
namespace Outer { 
	namespace Inner { 
		int i = 0; 
	}
}

int main(int, char**){
	using namespace Outer::Inner; 
	return i;
	}
