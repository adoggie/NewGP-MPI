
int main(int,char**) {
  long long int i = 1;
  }
