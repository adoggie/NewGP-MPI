
int f(int x){
    return 1;
    };

int f(char x){
    return 1;
    }; 

int f(bool x){
    return 1;
    };

 int main(int,char**) {
    bool b = true; 
    return f(b);
    }