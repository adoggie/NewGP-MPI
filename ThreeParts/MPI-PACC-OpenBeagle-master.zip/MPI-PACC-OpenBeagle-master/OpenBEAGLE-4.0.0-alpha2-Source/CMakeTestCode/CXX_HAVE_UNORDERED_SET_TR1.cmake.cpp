
#include <tr1/unordered_set>

using std::tr1::unordered_set;

class TestTr1UnorderedSetClass{
public:
	TestTr1UnorderedSetClass(){}
	inline void const_Find_Test() const{
		mTestUnorderedMap.find(0);
	}
private:
	std::tr1::unordered_set<int> mTestUnorderedMap;
};
 
int main(int,char**) {}
