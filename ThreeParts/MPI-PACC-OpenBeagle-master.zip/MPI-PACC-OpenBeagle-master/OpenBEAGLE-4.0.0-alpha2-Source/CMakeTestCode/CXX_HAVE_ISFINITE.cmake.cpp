#define _GNU_SOURCE
#include <cmath>

int main(int,char**){
	double d=0; 
	int n = std::isfinite(d);
	}
