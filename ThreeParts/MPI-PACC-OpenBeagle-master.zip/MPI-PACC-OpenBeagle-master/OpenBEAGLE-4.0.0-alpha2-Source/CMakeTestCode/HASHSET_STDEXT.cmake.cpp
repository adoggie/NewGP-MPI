#include <stdext/hash_set>

using stdext::hash_set; 

int main(int,char**) {}
