
template<class T = double, int N = 10> class A {
	public: 
	int f() {
		return 0;
		}
	};

int main(int, char**){
	A<float> a; 
	return a.f();
	}
