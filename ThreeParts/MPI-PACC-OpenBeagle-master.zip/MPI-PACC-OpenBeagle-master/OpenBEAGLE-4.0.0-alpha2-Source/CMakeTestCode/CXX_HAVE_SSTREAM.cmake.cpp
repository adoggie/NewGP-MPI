#include <sstream>


using namespace std;

int main(int,char**){
	stringstream message; 
	message << "Hello"; 
	return 0;
	}