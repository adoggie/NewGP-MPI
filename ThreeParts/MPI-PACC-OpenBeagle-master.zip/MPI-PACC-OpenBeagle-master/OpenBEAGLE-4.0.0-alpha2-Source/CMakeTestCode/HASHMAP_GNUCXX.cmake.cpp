#include <ext/hash_map>

using __gnu_cxx::hash_map; 

int main(int,char**) {}
